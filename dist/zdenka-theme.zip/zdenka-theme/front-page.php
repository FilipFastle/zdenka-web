<?php
defined('ABSPATH') || exit;
get_header();
if (have_posts()) { while (have_posts()) { the_post(); } }
$phone=zc_agent('phone','+421 907 579 742');
$wa=zc_agent('wa','421907579742');
$email=zc_agent('email',get_option('admin_email'));
$name=zc_agent('name','Mgr. Zdenka Cibuľová');
$title=zc_agent('title','Realitná maklérka');
?>
<?php
/* Hero je CSS pozadie, kde srcset nefunguje – preto si veľkosť vyberáme sami
   podľa obrazovky. Bez toho sa na mobil sťahoval originál z fotoaparátu. */
$zc_sized = function ($which, $size) {
    return function_exists('zc_photo_sized') ? zc_photo_sized($which, $size)
         : (function_exists('zc_photo') ? zc_photo($which) : '');
};
$zc_hero_portrait    = $zc_sized('portrait', 'large');      // ~1024 px, mobil
$zc_hero_portrait_2x = $zc_sized('portrait', 'zc-1440');    // mobil s retinou
?>
<style>
/* Hero je bežná súčasť stránky – po ňom nasleduje normálny scroll bez prekrývania. */
/* Hero vždy vyplní celé okno – aj keď si používateľ stránku oddiali.
   dvh berie do úvahy lištu prehliadača na mobile, vh je záloha pre staršie. */
.zc-home-hero{height:100vh;min-height:560px;margin-top:calc(-1 * var(--hh,72px));position:relative;overflow:hidden;display:flex;align-items:center}
@supports(height:100dvh){.zc-home-hero{height:100dvh}}
.zc-hero-bg{position:absolute;inset:0;background-size:cover;background-position:67% center;background-repeat:no-repeat}
/* Postupné nabehnutie hero obsahu pri načítaní (beží vždy, aj na PC) */
@keyframes zcRise{from{opacity:0;transform:translateY(26px)}to{opacity:1;transform:none}}
.zc-hero-text>*{animation:zcRise .7s cubic-bezier(.22,.9,.36,1) both}
.zc-hero-text>*:nth-child(1){animation-delay:.12s}
.zc-hero-text>*:nth-child(2){animation-delay:.24s}
.zc-hero-text>*:nth-child(3){animation-delay:.36s}
.zc-hero-text>*:nth-child(4){animation-delay:.48s}
.zc-hero-text>*:nth-child(5){animation-delay:.60s}
/* PC: fotka ostáva úplne čistá, bez akéhokoľvek prekryvu.
   Čitateľnosť drží vrstvený tieň písma – tesná tmavá aura okolo znakov
   plus mäkký nádych. Jeden rozmazaný tieň na svetlom mieste fotky nestačí,
   preto sú tri vrstvy: ostrá hrana, stredná a široká.

   Prvok .zc-hero-overlay tu ostáva bez pozadia – na mobile mu ho nastavuje
   médiový dotaz nižšie a bez tohto umiestnenia by tam prestal fungovať. */
.zc-hero-overlay{position:absolute;inset:0;background:none;z-index:1;pointer-events:none}
.zc-hero-text{position:relative;z-index:2;padding:calc(var(--hh,72px) + 40px) 64px 60px;max-width:660px;text-shadow:0 1px 2px rgba(0,0,0,.5),0 2px 10px rgba(0,0,0,.38),0 6px 28px rgba(0,0,0,.26)}
/* Štítok je malé písmo – norma naň žiada prísnejší kontrast 4,5:1,
   preto svetlejší odtieň zlatej než vo zvyšku webu. */
.zc-hero-eyebrow{display:inline-flex;align-items:center;gap:10px;font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#E8D6B0;margin-bottom:20px;font-family:var(--sans,sans-serif);text-shadow:0 0 2px rgba(0,0,0,.55),0 1px 2px rgba(0,0,0,.55),0 2px 10px rgba(0,0,0,.4)}
.zc-hero-eyebrow::before{content:'';width:28px;height:1.5px;background:#E8D6B0;display:block;box-shadow:0 0 4px rgba(0,0,0,.45)}
.zc-hero-h1{font-family:var(--serif,'Playfair Display',serif);font-size:clamp(36px,4.5vw,64px);font-weight:800;line-height:1.15;color:#fff;margin-bottom:24px;text-shadow:0 0 3px rgba(0,0,0,.4),0 1px 3px rgba(0,0,0,.5),0 3px 14px rgba(0,0,0,.38),0 8px 36px rgba(0,0,0,.26)}
.zc-hero-h1 em{color:#DCC79A;font-style:italic}
.zc-hero-p{font-size:clamp(15px,1.4vw,18px);color:#fff;line-height:1.8;margin-bottom:40px;font-family:var(--sans,sans-serif);text-shadow:0 0 2px rgba(0,0,0,.5),0 1px 2px rgba(0,0,0,.55),0 2px 12px rgba(0,0,0,.38)}
/* text-shadow sa dedí, takže z .zc-hero-text prepadol aj do tlačidiel
   a do vizitky – tam ho netreba, majú vlastné pozadie. Na zlatom tlačidle
   robil tmavý nápis špinavým. */
.zc-hero-btns{display:flex;gap:14px;flex-wrap:wrap}
.zc-hero-btns .zc-btn,.zc-hero-btns button,.zc-hero-name-card,.zc-hero-name-card *{text-shadow:none}
.zc-hero-name-card{margin-top:52px;display:inline-flex;align-items:center;gap:14px;padding:14px 20px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);border-radius:12px;backdrop-filter:blur(10px)}
.zc-hero-name-card-name{font-family:var(--serif,serif);font-size:15px;font-weight:700;color:#fff}
.zc-hero-name-card-role{font-size:10px;color:#DCC79A;letter-spacing:1.5px;text-transform:uppercase;margin-top:2px;font-family:var(--sans,sans-serif)}
.zc-hero-scroll{position:absolute;bottom:28px;left:50%;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;gap:8px;color:rgba(255,255,255,.94);text-shadow:0 1px 2px rgba(0,0,0,.55),0 2px 10px rgba(0,0,0,.4);font-size:10px;letter-spacing:1.5px;text-transform:uppercase;font-family:var(--sans,sans-serif);z-index:5;animation:heroScroll 2s ease-in-out infinite}
@keyframes heroScroll{0%,100%{transform:translateX(-50%) translateY(0)}50%{transform:translateX(-50%) translateY(7px)}}
<?php if ($zc_hero_portrait): ?>
/* Mobil: hero = vertikálny portrét – tvár je vycentrovaná z podstaty fotky */
@media(max-width:768px){
    /* fotka bez brightness filtra; tvár hore ostáva čistá, scrim je len dole pod textom */
    .zc-hero-bg{background-image:url('<?php echo esc_url($zc_hero_portrait); ?>') !important;background-position:center 18% !important;transform-origin:center 25%;filter:none !important}
<?php if ($zc_hero_portrait_2x && $zc_hero_portrait_2x !== $zc_hero_portrait): ?>
    @media(min-resolution:2dppx){.zc-hero-bg{background-image:url('<?php echo esc_url($zc_hero_portrait_2x); ?>') !important}}
<?php endif; ?>
    .zc-home-hero{align-items:flex-end}
    .zc-hero-text{padding:calc(var(--hh,60px) + 24px) 22px 80px;text-shadow:0 2px 16px rgba(0,0,0,.65)}
    /* menší nadpis nezasahuje do tváre */
    .zc-hero-h1{font-size:30px !important;line-height:1.12;margin-bottom:14px}
    .zc-hero-p{font-size:14.5px !important;line-height:1.6;margin-bottom:24px}
    .zc-hero-eyebrow{margin-bottom:12px}
    /* silnejší scrim dole (čitateľný text nad blúzkou), plynulo mizne pred tvárou */
    .zc-hero-overlay{background:linear-gradient(to top,rgba(18,15,12,.9) 0%,rgba(18,15,12,.8) 18%,rgba(18,15,12,.52) 40%,rgba(18,15,12,.2) 62%,rgba(18,15,12,0) 86%) !important}
}
<?php else: ?>
@media(max-width:768px){.zc-hero-text{padding:calc(var(--hh,60px) + 24px) 22px 56px;text-shadow:0 2px 16px rgba(0,0,0,.65)}.zc-hero-h1{font-size:30px !important;line-height:1.12}.zc-hero-p{font-size:14.5px !important}.zc-hero-overlay{background:linear-gradient(to top,rgba(18,15,12,.9) 0%,rgba(18,15,12,.8) 18%,rgba(18,15,12,.52) 40%,rgba(18,15,12,.2) 62%,rgba(18,15,12,0) 86%) !important}.zc-hero-bg{background-position:73% 24%;filter:none !important}}
<?php endif; ?>
</style>

<script>
(function(){
    var hdr=document.getElementById('zcHeader');
    if(!hdr)return;
    hdr.classList.add('transparent');
    function u(){if(!document.getElementById('zcHomeHero'))return;hdr.classList.toggle('transparent',window.scrollY < 24);}
    window.addEventListener('scroll',u,{passive:true});
})();
</script>

<div class="zc-home-hero" id="zcHomeHero">
    <?php
    // Hero fotka: Customizer (Fotky maklérky) → featured image stránky → tmavé pozadie
    $zc_hero_img    = $zc_sized('hero', 'zc-1440');           // bežné monitory
    $zc_hero_img_big = $zc_sized('hero', 'zc-2048');           // veľké monitory
    if (!$zc_hero_img && has_post_thumbnail()) $zc_hero_img = get_the_post_thumbnail_url(null, 'large');
    ?>
    <?php if($zc_hero_img): ?>
    <div class="zc-hero-bg" id="zcHeroBg" style="background-image:url('<?php echo esc_url($zc_hero_img); ?>')"></div>
    <?php if ($zc_hero_img_big && $zc_hero_img_big !== $zc_hero_img): ?>
    <style>@media(min-width:1441px){.zc-hero-bg{background-image:url('<?php echo esc_url($zc_hero_img_big); ?>')}}</style>
    <?php endif; ?>
    <?php else: ?><div class="zc-hero-bg" id="zcHeroBg" style="background:#1C1A18"></div><?php endif; ?>
    <div class="zc-hero-overlay"></div>
    <div class="zc-hero-text">
        <div class="zc-hero-eyebrow"><?php echo zc_t('home.badge') ?></div>
        <h1 class="zc-hero-h1"><?php echo zc_t('home.title') ?> <em><?php echo zc_t('home.title_hl') ?></em></h1>
        <p class="zc-hero-p"><?php echo zc_t('home.sub') ?></p>
        <div class="zc-hero-btns">
            <?php if (function_exists('zc_ebook_enabled') && zc_ebook_enabled()): zc_ebook_flag(true); ?>
            <button type="button" class="zc-btn zc-btn-primary zc-hero-ebook-btn" data-zc-ebook-open>
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="margin-right:2px"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg>
                Ebook PDF zdarma
            </button>
            <a href="<?php echo home_url('/ponuky/'); ?>" class="zc-btn" style="background:rgba(255,255,255,.12);color:#fff;border:1.5px solid rgba(255,255,255,.3)"><?php echo zc_t('home.btn1') ?></a>
            <?php else: ?>
            <a href="<?php echo home_url('/ponuky/'); ?>" class="zc-btn zc-btn-primary"><?php echo zc_t('home.btn1') ?></a>
            <a href="<?php echo home_url('/kontakt/'); ?>" class="zc-btn" style="background:rgba(255,255,255,.12);color:#fff;border:1.5px solid rgba(255,255,255,.3)"><?php echo zc_t('home.btn2') ?></a>
            <?php endif; ?>
        </div>
    </div>
    <div class="zc-hero-scroll">
        <span><?php echo zc_t('home.scroll') ?></span>
        <svg width="16" height="20" viewBox="0 0 16 20" fill="none"><rect x="1" y="1" width="14" height="18" rx="7" stroke="currentColor" stroke-width="1.5"/><circle cx="8" cy="6" r="2" fill="currentColor"/></svg>
    </div>
</div>

<!-- MOJE HODNOTY – v Prispôsobiť → Úvodná stránka – sekcie sa dá zapnúť -->
<?php if (get_theme_mod('zc_home_values', '0') === '1'): ?>
<section class="zc-section bg-section">
<div class="zc-container">
    <div style="text-align:center;max-width:580px;margin:0 auto 52px">
        <div class="zc-eyebrow" style="justify-content:center"><?php echo zc_t('home.values_eye') ?></div>
        <h2 style="font-family:var(--serif)"><?php echo zc_t('home.values_t') ?> <em><?php echo zc_t('home.values_hl') ?></em></h2>
    </div>
    <div class="zc-precoja-grid" style="display:grid;grid-template-columns:repeat(4,1fr);gap:22px">
    <?php foreach([
        ['heart','Záujem','Vaša spokojnosť je môj úspech. Každý prípad riešim osobne.'],
        ['bulb','Odbornosť','Trh sledujem denne. Znalosti využívam v prospech klienta.'],
        ['bolt','Rýchlosť','Váš čas je cenný. Komunikujem promptne a procesy urýchľujem.'],
        ['handshake','Férovosť','Vždy poviem pravdu, aj keď nie je príjemná. Žiadne skryté poplatky.'],
    ] as [$ic,$t,$d]): ?>
    <div class="zc-card"><div class="zc-card-icon" style="color:var(--accent-txt)"><?php echo zc_svg($ic, 26); ?></div><h3 style="font-size:17px;margin-bottom:8px"><?php echo $t; ?></h3><p style="font-size:14px;color:var(--muted);margin:0;line-height:1.7"><?php echo $d; ?></p></div>
    <?php endforeach; ?>
    </div>
</div>
</section>
<?php endif; ?>

<!-- PONUKY -->
<section class="zc-section bg-white">
<div class="zc-container">
    <div style="display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:48px;flex-wrap:wrap;gap:20px">
        <div><div class="zc-eyebrow"><?php echo zc_t('home.props_eye') ?></div><h2 style="font-family:var(--serif)"><?php echo zc_t('home.props_t') ?> <em><?php echo zc_t('home.props_hl') ?></em></h2></div>
        <a href="<?php echo home_url('/ponuky/'); ?>" class="zc-btn zc-btn-outline"><?php echo zc_t('home.props_all') ?></a>
    </div>
    <?php echo do_shortcode('[property_grid per_page="3"]'); ?>
</div>
</section>

<!-- REFERENCIE -->
<section class="zc-section bg-section">
<div class="zc-container">
    <div style="text-align:center;max-width:560px;margin:0 auto 52px">
        <div class="zc-eyebrow" style="justify-content:center"><?php echo zc_t('home.refs_eye') ?></div>
        <h2 style="font-family:var(--serif)"><?php echo zc_t('home.refs_t') ?> <em><?php echo zc_t('home.refs_hl') ?></em></h2>
    </div>
    <?php
    if (function_exists('zcr_table')) {
        // Všetky recenzie v karuseli – bez obmedzenia počtu
        echo do_shortcode('[zc_reviews carousel="1" cols="3"]');
        if (get_page_by_path('referencie')) {
            echo '<div style="text-align:center;margin-top:26px"><a href="' . esc_url(home_url('/referencie/')) . '" class="zc-btn zc-btn-outline">' . zc_t('home.refs_all') . '</a></div>';
        }
    } else {
        // Fallback – hardcoded kým plugin nie je aktívny
        $fallback = [
            ['Jana a Peter K.','Predaj rodinného domu','Zdenka predala náš dom za 3 týždne za cenu, o akej sme ani nesnívali. Profesionálny prístup, skvelá komunikácia.'],
            ['Miroslav T.','Kúpa 3-izbového bytu','Pomohla nám nájsť presne to, čo sme hľadali. Ušetrila nám kopu času a stresu.'],
            ['Katarína L.','Prenájom bytu','Rýchle, bezproblémové. Zdenka všetko zorganizovala, stačilo podpísať.'],
        ];
        echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:22px">';
        foreach ($fallback as [$a,$m,$q]) {
            echo '<div class="zc-testimonial"><div class="zc-stars">★★★★★</div>';
            echo '<div class="zc-testimonial-quote">'.esc_html($q).'</div>';
            echo '<div class="zc-testimonial-author"><div class="zc-testimonial-avatar"></div>';
            echo '<div><div class="zc-testimonial-name">'.esc_html($a).'</div>';
            echo '<div class="zc-testimonial-meta">'.esc_html($m).'</div></div></div></div>';
        }
        echo '</div>';
    }
    ?>
</div>
</section>

<!-- CTA -->
<section style="background:var(--section);padding:100px 0;border-top:1px solid var(--border)">
<div class="zc-container zc-cta-grid" style="display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center">
    <div>
        <div class="zc-eyebrow"><?php echo zc_t('home.cta_eye') ?></div>
        <h2 style="font-family:var(--serif);margin-bottom:16px"><?php echo zc_t('home.cta_t') ?> <em><?php echo zc_t('home.cta_hl') ?></em></h2>
        <p style="color:var(--muted);font-size:16px;line-height:1.75;margin-bottom:32px"><?php echo zc_t('home.cta_sub') ?></p>
        <?php foreach([
            ['<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z"/></svg>',$phone,"tel:".preg_replace('/[^0-9+]/','',$phone)],
            ['<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>','WhatsApp',"https://wa.me/".preg_replace('/[^0-9]/','',$wa)],
            ['<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,12 2,6"/></svg>',$email,"mailto:".esc_attr($email)],
        ] as [$ic,$lbl,$href]): ?>
        <a href="<?php echo $href; ?>" class="zc-cta-contact" style="display:flex;align-items:center;gap:12px;color:var(--text);font-size:15px;text-decoration:none;margin-bottom:14px">
            <span class="zc-cta-contact-icon" style="width:44px;height:44px;background:var(--white);border:1px solid var(--border);color:var(--accent-dk);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .25s var(--ease)"><?php echo $ic; ?></span>
            <?php echo esc_html($lbl); ?>
        </a>
        <?php endforeach; ?>
        <?php $zc_cta_soc = function_exists('zc_social_icons_html') ? zc_social_icons_html() : ''; ?>
        <?php if ($zc_cta_soc): ?>
        <div style="margin-top:24px"><?php echo $zc_cta_soc; ?></div>
        <?php endif; ?>
    </div>
    <div class="zc-cta-card" style="background:var(--white);border:1px solid var(--border);border-radius:var(--r-lg);padding:40px;box-shadow:var(--sh)">
        <h3 style="font-family:var(--serif);font-size:22px;margin-bottom:24px"><?php echo zc_t('home.form_t') ?></h3>
        <form id="zcContactForm" style="position:relative">
            <?php echo function_exists('zc_honeypot_fields') ? zc_honeypot_fields() : ''; ?>
            <?php foreach([['name','text','Vaše meno *'],['email','email','E-mail *'],['phone','tel','Telefón']] as [$n,$t,$p]): ?>
            <div style="margin-bottom:12px"><input type="<?php echo $t; ?>" name="<?php echo $n; ?>" placeholder="<?php echo $p; ?>" class="zc-cta-input" style="background:var(--bg);border:1.5px solid var(--border);color:var(--text);padding:13px 16px;border-radius:var(--r-sm);width:100%;font-family:var(--sans);font-size:16px" <?php if(substr($p, -strlen('*')) === '*') echo 'required'; ?>></div>
            <?php endforeach; ?>
            <div style="margin-bottom:16px"><textarea name="message" placeholder="Správa" rows="4" class="zc-cta-input" style="background:var(--bg);border:1.5px solid var(--border);color:var(--text);padding:13px 16px;border-radius:var(--r-sm);width:100%;font-family:var(--sans);font-size:16px;resize:vertical"></textarea></div>
            <label style="display:flex;align-items:flex-start;gap:9px;font-size:12px;color:var(--muted);cursor:pointer;line-height:1.55;margin-bottom:10px">
                <input type="checkbox" name="gdpr" required style="margin-top:2px;accent-color:var(--accent);flex-shrink:0">
                <span>Súhlasím so <a href="/ochrana-osobnych-udajov/" style="color:var(--accent-txt)">spracovaním osobných údajov</a> za účelom odpovede na môj dopyt. *</span>
            </label>
            <label style="display:flex;align-items:flex-start;gap:9px;font-size:12px;color:var(--muted);cursor:pointer;line-height:1.55;margin-bottom:16px">
                <input type="checkbox" name="newsletter" style="margin-top:2px;accent-color:var(--accent);flex-shrink:0">
                <span>Chcem dostávať novinky a nové ponuky nehnuteľností na e-mail.</span>
            </label>
            <div id="zcFormMsg"></div>
            <button type="submit" class="zc-btn zc-btn-primary" style="width:100%;justify-content:center">Odoslať správu →</button>
        </form>
    </div>
</div>
</section>

<?php /* PDF ebook – pod kontaktným formulárom; zobrazí sa len keď je zapnutý v paneli → Ebook */ ?>
<?php if (shortcode_exists('zc_ebook')) echo do_shortcode('[zc_ebook]'); ?>

<?php get_footer(); ?>
